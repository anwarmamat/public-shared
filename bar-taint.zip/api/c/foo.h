void bar(char * a, char **b);
