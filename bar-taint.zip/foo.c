#include <string.h> 
#include <stdlib.h>
#include <stdio.h>
#include "api/c/foo.h"

void bar(char * a, char **b) { 
  strcpy(*b,a);
}

int main(){
  char src[100] = "source";
  char dst[100] = "destination";
  char *t = dst;
  bar(src,&t);
  return 0;
}
