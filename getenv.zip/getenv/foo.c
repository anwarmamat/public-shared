#include <stdlib.h>
#include "api/c/foo.h"

char * foo() {
    char *c = getenv("HOME");
    c = NULL;
    return c;
}
