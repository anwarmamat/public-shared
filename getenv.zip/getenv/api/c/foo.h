char *foo ();
