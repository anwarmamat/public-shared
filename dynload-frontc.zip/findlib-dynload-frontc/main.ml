let () = print_endline "main: init"

let () =
    try
      Fl_dynload.load_packages ["bar"];
    with
    | Fl_package_base.No_such_package(pkg, _) ->
      Printf.printf "The package %S can't be found.\n%!" pkg
    | Dynlink.Error error ->
      Printf.printf "Error during dynlink: %s\n%!" (Dynlink.error_message error)
    |_->failwith "error"
;;

