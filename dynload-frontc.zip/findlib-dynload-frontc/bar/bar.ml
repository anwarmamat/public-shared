open Frontc

let () = print_endline "Bar: init"
let bar () = "Bar is called"

let () = Printf.printf "%s\n" (bar ())

let parse f =
  match parse_file f stderr with
  | PARSING_ERROR -> Printf.printf "parse failed\n" 
  | PARSING_OK _ast -> Printf.printf "parsed\n"

let () = parse "./test.c"
