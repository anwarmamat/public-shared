#include <string.h> 
#include <stdlib.h>
#include "api/c/foo.h"
//void bar(){}
char * foo(char *c) { 
  if(c == NULL)
    return NULL;
  //char *x = malloc(strlen(c));
  //strcpy(x,c);
  return c;
}

