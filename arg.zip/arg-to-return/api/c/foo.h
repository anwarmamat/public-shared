char * foo(char *c);

