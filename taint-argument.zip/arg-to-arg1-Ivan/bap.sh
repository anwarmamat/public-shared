bap ./foo.o --run \
    --no-glibc-runtime \
    --run-entry-points=entry-foo \
    --primus-limit-max-length=32768 \
    --primus-promiscuous-mode \
    --primus-greedy-scheduler \
    --primus-lisp-add=./callback \
    --primus-lisp-load=posix,entry,taints \
    --llvm-base=0x400000 \
    --log-dir=./log \
    --api-path=./api \
    --primus-print-obs=lisp-message
#,taint-attached



#    --primus-propagate-taint-from-attributes \
#    --primus-propagate-taint-to-attributes \

