#include <string.h> 
#include <stdlib.h>
#include <stdio.h>
#include "api/c/foo.h"

void foo(char * a, char **b) { 
  *b = a;
 }

/*
void foo(char * a, char **b) { 
  strcpy(*b,a);
}
*/

int main(){
  char *src = "source";
  char dst[128] = "destination";
  char *b = dst;
  foo(src,&b);
  printf("src: %s\t dst:%s\t b:%s\n", src, dst, b);
  return 0;
}
