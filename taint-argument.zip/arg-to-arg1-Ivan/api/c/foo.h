void foo(char * a, char **b);
